Fixed-block signaling divides track into blocks; a train may enter only if the block is clear.
Moving-block signaling uses continuous train control to reduce headways and increase capacity.
